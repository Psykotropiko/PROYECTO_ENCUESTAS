package com.example.survey4u;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
public class encuestas extends AppCompatActivity {
    ArrayAdapter adaptador;
    ArrayList<String> listado_encuestas = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listado_encuesta);
        adaptador = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
        final RequestQueue queue = Volley.newRequestQueue(this);
        ListView listado = (ListView) findViewById(R.id.listado);
        listado.setAdapter(adaptador);
        String url ="http://192.168.1.131:8080/Encuestas/webresources/ws/encuestas/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Gson conversor = new Gson();
                        List<EncuestaDTO> encuestas = conversor.fromJson(response,new TypeToken<List<EncuestaDTO>>(){}.getType());
                        for (EncuestaDTO enc : encuestas) {
                            listado_encuestas.add(enc.getNombre());
                        }
                        adaptador.addAll(listado_encuestas);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }

});
        queue.add(stringRequest);

        listado.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item text from ListView
                String selectedItem = (String) parent.getItemAtPosition(position);
                setContentView(R.layout.activity_formulario);
            }
        });
    }
}
}