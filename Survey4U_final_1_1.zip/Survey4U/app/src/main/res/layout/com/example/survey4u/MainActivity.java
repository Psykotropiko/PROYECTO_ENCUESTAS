package com.example.survey4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;




public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView correo =  findViewById(R.id.correo);
        final TextView pass =  findViewById(R.id.password);
        final RequestQueue queue = Volley.newRequestQueue(this);
        final Button validar = findViewById(R.id.validar);
        final Button crear_usuario = findViewById(R.id.button2);
        validar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String url ="http://192.168.1.130:8080/Encuestas/webresources/ws/login/"+correo.getText()+"/"+pass.getText()+"/";
                Log.i("Conexion url", url);

                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response != null && response.isEmpty() == false) {
                                    Gson yokse = new Gson();
                                    UsuariosDTO user = yokse.fromJson(response,UsuariosDTO.class);
                                    Context context = getApplicationContext();
                                    CharSequence text = "Vamos a las encuestas! :)";
                                    int duration = Toast.LENGTH_SHORT;

                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                    setContentView(R.layout.listado_encuesta);
                                }else{
                                    Context context = getApplicationContext();
                                    CharSequence text = "LOL! Datos invalidos";
                                    int duration = Toast.LENGTH_SHORT;

                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                queue.add(stringRequest);

            }
        });

        crear_usuario.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setContentView(R.layout.registrar_usuario);
            }
        });



    }
}
