package com.example.survey4u;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class registrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar_usuario);
        final TextView correo = findViewById(R.id.correo2);
        final TextView pass = findViewById(R.id.password2);
        final Button crear = findViewById(R.id.crear);
        final RequestQueue queue = Volley.newRequestQueue(this);
        crear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String url = "http://192.168.1.130:8080/Encuestas/websources/ws/registro/"+correo.getText()+"/"+pass.getText()+"/";
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response == null && response.isEmpty() == true) {
                                    Gson yokse = new Gson();
                                    UsuariosDTO user = yokse.fromJson(response,UsuariosDTO.class);
                                    Context context = getApplicationContext();
                                    CharSequence text = "Vamos a las encuestas! :)";
                                    int duration = Toast.LENGTH_SHORT;

                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                    setContentView(R.layout.listado_encuesta);
                                }else{
                                    Context context = getApplicationContext();
                                    CharSequence text = "LOL! Datos invalidos";
                                    int duration = Toast.LENGTH_SHORT;

                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                queue.add(stringRequest);
            }
        });
    }
}
