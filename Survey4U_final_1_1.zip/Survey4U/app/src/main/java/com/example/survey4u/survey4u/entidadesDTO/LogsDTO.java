package com.example.survey4u.survey4u.entidadesDTO;

import android.os.Build;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import androidx.annotation.RequiresApi;

public class LogsDTO implements Serializable {
    private Integer id_log;
    private Integer id_usuario;
    private Integer id_encuesta;
    private Date fecha;

    public LogsDTO(){

    }

    public Integer getId_log() {
        return id_log;
    }

    public void setId_log(Integer id_log) {
        this.id_log = id_log;
    }

    public Integer getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(Integer id_usuario) {
        this.id_usuario = id_usuario;
    }

    public Integer getId_encuesta() {
        return id_encuesta;
    }

    public void setId_encuesta(Integer id_encuesta) {
        this.id_encuesta = id_encuesta;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id_log);
        hash = 97 * hash + Objects.hashCode(this.id_usuario);
        hash = 97 * hash + Objects.hashCode(this.id_encuesta);
        hash = 97 * hash + Objects.hashCode(this.fecha);
        return hash;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LogsDTO other = (LogsDTO) obj;
        if (!Objects.equals(this.id_log, other.id_log)) {
            return false;
        }
        if (!Objects.equals(this.id_usuario, other.id_usuario)) {
            return false;
        }
        if (!Objects.equals(this.id_encuesta, other.id_encuesta)) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Logs{" + "id_log=" + id_log + ", id_usuario=" + id_usuario + ", id_encuesta=" + id_encuesta + ", fecha=" + fecha + '}';
    }



}

