package com.example.survey4u.survey4u.entidadesDTO;

import java.io.Serializable;
import java.util.List;

public class PreguntaDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer id;
    private String tituloPregunta;
    private Boolean esMultiple;
    private List<RespuestaDTO> respuestaList;

    public PreguntaDTO() {
    }

    public PreguntaDTO(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTituloPregunta() {
        return tituloPregunta;
    }

    public void setTituloPregunta(String tituloPregunta) {
        this.tituloPregunta = tituloPregunta;
    }

    public Boolean getEsMultiple() {
        return esMultiple;
    }

    public void setEsMultiple(Boolean esMultiple) {
        this.esMultiple = esMultiple;
    }



    public List<RespuestaDTO> getRespuestaList() {
        return respuestaList;
    }

    public void setRespuestaList(List<RespuestaDTO> respuestaList) {
        this.respuestaList = respuestaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PreguntaDTO)) {
            return false;
        }
        PreguntaDTO other = (PreguntaDTO) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EncuestasActivity.entity.Pregunta[ id=" + id + " ]";
    }


}