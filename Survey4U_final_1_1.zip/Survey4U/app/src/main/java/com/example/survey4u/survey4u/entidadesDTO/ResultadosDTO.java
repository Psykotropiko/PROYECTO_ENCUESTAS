package com.example.survey4u.survey4u.entidadesDTO;

import android.os.Build;

import java.io.Serializable;
import java.util.Objects;

import androidx.annotation.RequiresApi;

public class ResultadosDTO implements Serializable {
    private Integer id_log;
    private Integer id_pregunta;
    private Integer id_respuesta;

    public Integer getId_log() {
        return id_log;
    }

    public void setId_log(Integer id_log) {
        this.id_log = id_log;
    }

    public Integer getId_pregunta() {
        return id_pregunta;
    }

    public void setId_pregunta(Integer id_pregunta) {
        this.id_pregunta = id_pregunta;
    }

    public Integer getId_respuesta() {
        return id_respuesta;
    }

    public void setId_respuesta(Integer id_respuesta) {
        this.id_respuesta = id_respuesta;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.id_log);
        hash = 37 * hash + Objects.hashCode(this.id_pregunta);
        hash = 37 * hash + Objects.hashCode(this.id_respuesta);
        return hash;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ResultadosDTO other = (ResultadosDTO) obj;
        if (!Objects.equals(this.id_log, other.id_log)) {
            return false;
        }
        if (!Objects.equals(this.id_pregunta, other.id_pregunta)) {
            return false;
        }
        if (!Objects.equals(this.id_respuesta, other.id_respuesta)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ResultadosDTO{" + "id_log=" + id_log + ", id_pregunta=" + id_pregunta + ", respuesta=" + id_respuesta + '}';
    }



}
