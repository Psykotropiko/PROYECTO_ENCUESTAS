package com.example.survey4u.survey4u.decodificar;

import com.example.survey4u.survey4u.entidadesDTO.LogsDTO;
import com.example.survey4u.survey4u.entidadesDTO.PreguntaDTO;
import com.example.survey4u.survey4u.entidadesDTO.RespuestaDTO;
import com.example.survey4u.survey4u.entidadesDTO.UsuariosDTO;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;

import java.util.List;

public class Decodificar {

    public Decodificar(){}
    public UsuariosDTO decoficarUsuariosDTO(String archivo){
        Gson gson = new Gson();
        UsuariosDTO usuario = gson.fromJson(archivo, UsuariosDTO.class);
        return usuario;
    }

    public LogsDTO decodificarLogs(String archivo){
        Gson gson = new Gson();
        LogsDTO log = gson.fromJson(archivo, LogsDTO.class);
        return log;
    }

    public List<RespuestaDTO> decodificarListaRespuesta(String archivo){
        Gson gson = new Gson();
        List<RespuestaDTO> lista = gson.fromJson(archivo, new TypeToken<List<RespuestaDTO>>(){}.getType());
        return lista;
    }

    public List<PreguntaDTO> decodificarListaPregunta(String archivo){
        Gson gson = new Gson();
        List<PreguntaDTO> lista = gson.fromJson(archivo, new TypeToken<List<PreguntaDTO>>(){}.getType());
        return lista;
    }

    public List<LogsDTO> decodificarListaLogs(String archivo){
        Gson gson = new Gson();
        List<LogsDTO> lista = gson.fromJson(archivo, new TypeToken<List<LogsDTO>>(){}.getType());
        return lista;
    }

}
