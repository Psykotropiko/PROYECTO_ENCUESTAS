package com.example.survey4u.survey4u.activity;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.survey4u.R;
import com.example.survey4u.survey4u.decodificar.Decodificar;
import com.example.survey4u.survey4u.entidadesDTO.PreguntaDTO;
import java.io.UnsupportedEncodingException;
import java.util.List;
public class FormularioActivity extends AppCompatActivity {
    String titulo_enc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);
        TextView texto = (TextView) findViewById(R.id.prueba);
        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre_encuesta");
        titulo_enc = "Encuesta de " + nombre;
        peticionHttp(texto, this);
    }
    private void peticionHttp(final TextView textView, final Context context) {
        RequestQueue queue = Volley.newRequestQueue(this);
        Bundle bundle = getIntent().getExtras();
        final String id_encuesta = bundle.getString("id_encuesta");
        final String id_usuario = bundle.getString("id_usuario");
        final String nombre_encuesta = bundle.getString("nombre_encuesta");
        String url = "http://192.168.1.131:8080/Encuestas/webresources/ws/listado_pregunta/"+id_encuesta;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    textView.setText(new String(response.getBytes("ISO-8859-1"), "UTF-8"));
                    Decodificar  decodificar = new Decodificar();
                    final List<PreguntaDTO>  preguntas = decodificar.decodificarListaPregunta(textView.getText().toString());
                    TextView a = (TextView) findViewById(R.id.prueba);

                    TextView titulo_encuesta = (TextView) findViewById(R.id.titulo_encuesta);
                    titulo_encuesta.setText(titulo_enc);
                    a.setVisibility(View.INVISIBLE);
                    final AdaptadorEncuestaPregunta adaptadorEncuestaPregunta = new AdaptadorEncuestaPregunta(context, preguntas);
                    ListView listado_respuestas = (ListView) findViewById(R.id.lista);
                    listado_respuestas.setAdapter(adaptadorEncuestaPregunta);
                    crearLog(context,id_usuario,id_encuesta,textView);
                    Button boton = (Button) findViewById(R.id.guarda);
                    boton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent = new Intent(view.getContext(), EncuestasActivity.class);
                            intent.putExtra("id_usuario", id_usuario);
                            startActivity(intent);
                        }
                    });
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("That didn't work!");
            }
        });
        queue.add(stringRequest);
    }
    private void crearLog(Context context,String id_usuario, String id_encuesta, final TextView textView){
        RequestQueue queue1 = Volley.newRequestQueue(context);
        String url1 = "http://192.168.1.131:8080/Encuestas/webresources/ws/log/add/"+id_usuario+"/"+id_encuesta;
        StringRequest stringRequest1 = new StringRequest(Request.Method.POST, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("Se crea el log");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("That didn't work!");
            }
        });
        queue1.add(stringRequest1);
    }
}