package com.example.survey4u.survey4u.activity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.survey4u.R;
import com.example.survey4u.survey4u.entidadesDTO.EncuestaDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
public class EncuestasActivity extends AppCompatActivity {
    ArrayAdapter adaptador;
    ArrayList<String> listado_encuestas = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listado_encuesta);
        adaptador = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
        final RequestQueue queue = Volley.newRequestQueue(this);
        final ListView listado = (ListView) findViewById(R.id.listado);
        listado.setAdapter(adaptador);
        String url ="http://192.168.1.131:8080/Encuestas/webresources/ws/encuestas/";
        final Context context = this;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(String response) {
                        Gson conversor = new Gson();
                        final List<EncuestaDTO> encuestas;
                        try {
                            encuestas = conversor.fromJson(new String(response.getBytes("ISO-8859-1"), "UTF-8"),new TypeToken<List<EncuestaDTO>>(){}.getType());
                            for (EncuestaDTO enc : encuestas) {
                                listado_encuestas.add(enc.getNombre());
                                listado.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        // Get the selected item text from ListView
                                        Bundle bundle = getIntent().getExtras();
                                        String id_usuario = bundle.getString("id_usuario");
                                        Intent intent = new Intent(view.getContext(), FormularioActivity.class);
                                        intent.putExtra("id_encuesta", encuestas.get(position).getId().toString());
                                        intent.putExtra("nombre_encuesta", encuestas.get(position).getNombre());
                                        intent.putExtra("id_usuario", id_usuario);

                                        startActivity(intent);
                                    }
                                });
                            }
                            adaptador.addAll(listado_encuestas);
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        queue.add(stringRequest);
    }
}
