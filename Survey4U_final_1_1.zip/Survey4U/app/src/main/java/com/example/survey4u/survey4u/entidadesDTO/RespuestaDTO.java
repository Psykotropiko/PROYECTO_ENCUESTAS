package com.example.survey4u.survey4u.entidadesDTO;

import java.io.Serializable;
import java.util.List;

public class RespuestaDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;
    private Integer id_pregunta;
    private String respuesta;
    private List<ResultadosDTO> listaResultados;


    public RespuestaDTO() {
    }

    public RespuestaDTO(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public List<ResultadosDTO> getListResultados(){
        return listaResultados;
    }

    public void setListResultados(List<ResultadosDTO> lista){
        listaResultados=lista;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RespuestaDTO)) {
            return false;
        }
        RespuestaDTO other = (RespuestaDTO) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EncuestasActivity.entity.Respuesta[ id=" + id + " ]";
    }

    public Integer getId_pregunta() {
        return id_pregunta;
    }

    public void setId_pregunta(Integer id_pregunta) {
        this.id_pregunta = id_pregunta;
    }

    public List<ResultadosDTO> getListaResultados() {
        return listaResultados;
    }

    public void setListaResultados(List<ResultadosDTO> listaResultados) {
        this.listaResultados = listaResultados;
    }

}
