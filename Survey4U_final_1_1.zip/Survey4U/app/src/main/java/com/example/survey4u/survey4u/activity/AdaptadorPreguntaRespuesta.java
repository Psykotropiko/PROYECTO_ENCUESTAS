package com.example.survey4u.survey4u.activity;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.survey4u.R;
import com.example.survey4u.survey4u.decodificar.Decodificar;
import com.example.survey4u.survey4u.entidadesDTO.LogsDTO;
import com.example.survey4u.survey4u.entidadesDTO.RespuestaDTO;


import java.util.ArrayList;
import java.util.List;

public class AdaptadorPreguntaRespuesta extends BaseAdapter {
    private Context context;
    private List<RespuestaDTO> listItems;
    private List<Integer> ids;
    public AdaptadorPreguntaRespuesta(Context context, List<RespuestaDTO> listItems){
        this.context = context;
        this.listItems = listItems;
        ids = new ArrayList<>(1);


    }

    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public Object getItem(int i) {
        return listItems.get(i);
    }

    @Override
    public long getItemId(int i) {
        return listItems.get(i).getId();
    }

    public List<Integer> getIds(){
        return this.ids;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = LayoutInflater.from(context).inflate(R.layout.activity_respuesta, null);
        RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.respuestas);
        for(RespuestaDTO respuestaDTO : listItems){
            RadioButton radioButton = new RadioButton(context);
            radioButton.setId(respuestaDTO.getId());
            radioButton.setText(respuestaDTO.getRespuesta());
            radioGroup.addView(radioButton);
        }


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, final int i) {

                ids.add(radioGroup.getCheckedRadioButtonId());
                if(ids.size()==1) {
                    RequestQueue queue1 = Volley.newRequestQueue(context);
                    String url1 = "http://192.168.43.248:8080/Encuestas/webresources/ws/get/listaLogs";
                    StringRequest stringRequest1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Decodificar decodificar = new Decodificar();
                            List<LogsDTO> lista_logs =  decodificar.decodificarListaLogs(response);
                            Log.d("LOGS", lista_logs.get(lista_logs.size()-1).toString());
                            for(RespuestaDTO respuestaDTO : listItems){
                                if(respuestaDTO.getId()==ids.get(0)){
                                    guardarResultado(context, respuestaDTO.getId_pregunta(), respuestaDTO.getId(), lista_logs.get(lista_logs.size()-1).getId_log());
                                }
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("LOGS", "error");
                        }
                    });
                    queue1.add(stringRequest1);
                }


            }
        });

        return view;
    }
    private void guardarResultado(Context c, final Integer id_pregunta, final Integer id_respuesta, final Integer id_log){
        RequestQueue queue1 = Volley.newRequestQueue(context);
        String url1 = "http://192.168.1.131:8080/Encuestas/webresources/ws/resultado/add/"+""+id_pregunta+"/"+""+id_respuesta+"/"+""+id_log;
        StringRequest stringRequest1 = new StringRequest(Request.Method.POST, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.v("OK", ""+id_pregunta);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.v("OK", ""+id_pregunta);
                Log.v("OK", ""+id_respuesta);
                Log.v("OK", ""+id_log);
            }
        });
        queue1.add(stringRequest1);
    }
}
