package com.example.survey4u.survey4u.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.survey4u.R;
import com.example.survey4u.survey4u.entidadesDTO.UsuariosDTO;
import com.google.gson.Gson;


public class RegistrarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar_usuario);
        final TextView correo2 = findViewById(R.id.correo2);
        final TextView pass2 = findViewById(R.id.password2);
        final Button crear = findViewById(R.id.crear);
        final RequestQueue queue = Volley.newRequestQueue(this);
        crear.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {

                String url = "http://192.168.1.131:8080/Encuestas/webresources/ws/registro/newuser/"+correo2.getText()+"/"+pass2.getText()+"/";
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response == null && response.isEmpty() == true) {
                                    Context context = getApplicationContext();
                                    CharSequence text = "Usuario creado! :)";
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                    Intent intent = new Intent(v.getContext(), MainActivity.class);
                                    startActivity(intent);
                                }else{
                                    Context context = getApplicationContext();
                                    CharSequence text = "LOL! Datos invalidos";
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                queue.add(stringRequest);
            }
        });
    }
}
