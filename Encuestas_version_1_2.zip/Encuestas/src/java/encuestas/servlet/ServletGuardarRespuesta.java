
package encuestas.servlet;


import encuestas.ejb.EncuestaFacade;
import encuestas.ejb.LogsFacade;
import encuestas.ejb.PreguntaFacade;
import encuestas.ejb.RespuestaFacade;
import encuestas.ejb.ResultadosFacade;
import encuestas.entity.Encuesta;
import encuestas.entity.Logs;
import encuestas.entity.Pregunta;
import encuestas.entity.Respuesta;
import encuestas.entity.Resultados;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ServletGuardarRespuesta", urlPatterns = {"/ServletGuardarRespuesta"})
public class ServletGuardarRespuesta extends HttpServlet {

    @EJB
    private EncuestaFacade encuestaFacade;

    @EJB
    private RespuestaFacade respuestaFacade;

    

    @EJB
    private PreguntaFacade preguntaFacade;

    @EJB
    private ResultadosFacade resultadosFacade;

    @EJB
    private LogsFacade logsFacade;

   

    

    

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        HttpSession sesion = request.getSession();
        String id_encuesta= request.getParameter("idencuesta");
        Integer id_log = (Integer)sesion.getAttribute("id_log");

//        List<Integer> listado = (List)sesion.getAttribute("listaresp");

        Encuesta encuesta = this.encuestaFacade.find(new Integer(id_encuesta));
        Logs log = this.logsFacade.find(id_log);
        if (log.getResultadosList() == null) {
            log.setResultadosList(new ArrayList());
        }
        
        for(Pregunta preg : encuesta.getPreguntaList()){
            String idrespuesta = request.getParameter("" + preg.getId());
            Respuesta respuesta = this.respuestaFacade.find(new Integer(idrespuesta));
            Resultados results = new Resultados(log.getId(),preg.getId());
                results.setLogs(log);
                results.setPregunta(preg);
                results.setIdRespuesta(respuesta);
             log.getResultadosList().add(results);
            this.resultadosFacade.create(results);   
        }
        this.logsFacade.edit(log);
        
        
       
        
          
        
        
        RequestDispatcher rd = request.getRequestDispatcher("ServletListarEncuesta");
        rd.forward(request, response);
        
        
    }

    
    
    
    
    
    
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
