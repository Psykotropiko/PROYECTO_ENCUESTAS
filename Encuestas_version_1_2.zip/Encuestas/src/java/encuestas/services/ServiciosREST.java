/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encuestas.services;

import encuestas.ejb.EncuestaFacade;
import encuestas.ejb.LogsFacade;
import encuestas.ejb.PreguntaFacade;
import encuestas.ejb.RespuestaFacade;
import encuestas.ejb.ResultadosFacade;
import encuestas.ejb.UsuariosFacade;
import encuestas.entity.Encuesta;
import encuestas.entity.Logs;
import encuestas.entity.Pregunta;
import encuestas.entity.Respuesta;
import encuestas.entity.Resultados;
import encuestas.entity.Usuarios;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Manuel
 */
@Stateless
@Path("ws")
public class ServiciosREST {

    @EJB
    private ResultadosFacade resultadosFacade;
    
    @EJB
    private RespuestaFacade respuestaFacade;
    
    @EJB
    private PreguntaFacade preguntaFacade;
    
    @EJB
    private EncuestaFacade encuestaFacade;
    
    @EJB
    private LogsFacade logsFacade;
    
    @EJB
    private UsuariosFacade usuariosFacade;

    //SERVICIO DE LOGIN.
    @GET
    @Path("login/{correo}/{pass}")
    @Produces({MediaType.APPLICATION_JSON})
    public Usuarios find(@PathParam("correo") String correo,@PathParam("pass") String password) {
        Usuarios user = this.usuariosFacade.comprobarUsuario(correo);  
        
        if (user == null || !user.getPassword().equals(password)) {
          return null;
        }else{    
          return user;
        }          
    }
    //SERVICIO DE REGISTRO
    @POST
//    @Override
    @Path("registro/newuser/{correo2}/{pass2}")
    @Consumes({MediaType.APPLICATION_JSON})
    public String Registro( @PathParam("correo2") String correoAR, @PathParam("pass2")String passwordAR) {
        String message = "Error, el usuario ya existe";
        Usuarios user = this.usuariosFacade.comprobarUsuario(correoAR);
            if (user == null || !user.getCorreo().equals(correoAR)) {
                Usuarios nuevo = new Usuarios();
                nuevo.setCorreo(correoAR);
                nuevo.setPassword(passwordAR);
                nuevo.setStatus("1");
                this.usuariosFacade.create(nuevo);
            } else {
            return message;
            }
        return null;
    }
    // AÑADIR LOG A DB
    @POST
    @Path("log/add/{id_usuario}/{id_encuesta}")
    public void añadirLog(@PathParam("id_usuario") String id_usuario, @PathParam("id_encuesta") String id_encuesta){
        Usuarios usuario = this.usuariosFacade.find(new Integer(id_usuario));
        Encuesta encuesta = this.encuestaFacade.find(new Integer(id_encuesta));
        // Se crea el log
        Logs log = new Logs();
        log.setIdUsuario(usuario);
        log.setIdEncuesta(encuesta);
        log.setFecha(new Date());
        this.logsFacade.create(log);
    }
    
    // DEVOLVER LOG MEDIANTE ID
    @GET
    @Path("get/log/{id_log}")
    @Produces({MediaType.APPLICATION_JSON})
    public Logs findLog(@PathParam("id_log") String id_log){
        return this.logsFacade.find(new Integer(id_log));
    }
    
    @POST
    @Path("resultado/add/{id_pregunta}/{id_respuesta}/{id_log}")
    public void añadirResultado(@PathParam("id_pregunta") String id_pregunta, @PathParam("id_respuesta") String id_respuesta, @PathParam("id_log") String id_log){
        Pregunta pregunta = this.preguntaFacade.find(new Integer(id_pregunta));
        Respuesta respuesta = this.respuestaFacade.find(new Integer(id_respuesta));
        Logs log = this.logsFacade.find(new Integer(id_log));
        //Se crea los resultados
        Resultados resultado = new Resultados(log.getId(), pregunta.getId());
        resultado.setLogs(log);
        resultado.setPregunta(pregunta);
        resultado.setIdRespuesta(respuesta);
        this.resultadosFacade.create(resultado);
    }
}
 
    
    

/*
    @PersistenceContext(unitName = "EncuestasPU")
    private EntityManager em;

    public ServiciosREST() {
        super(Usuarios.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_JSON})
    public void create(Usuarios entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Usuarios entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public Usuarios find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_JSON})
    public List<Usuarios> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_JSON})
    public List<Usuarios> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
*/

