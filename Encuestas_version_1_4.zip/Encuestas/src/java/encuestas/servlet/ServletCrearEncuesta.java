/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encuestas.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import encuestas.ejb.EncuestaFacade;
import encuestas.ejb.UsuariosFacade;
import encuestas.entity.Encuesta;
import encuestas.entity.Usuarios;

/**
 *
 * @author RENO
 */
@WebServlet(name = "ServletCrearEncuesta", urlPatterns = {"/ServletCrearEncuesta"})
public class ServletCrearEncuesta extends HttpServlet {

    @EJB
    private EncuestaFacade encuestaFacade;

    @EJB
    private UsuariosFacade usuariosFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
       
        String id = request.getParameter("id");
        Integer id_int = new Integer(id);
        Encuesta encuesta = new Encuesta ();
        
        
        if(id_int < 0){
            
            
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        
        
        
        Usuarios usuario = this.usuariosFacade.find(1);
        
        
        encuesta.setNombre(nombre);
        encuesta.setDescripcion(descripcion);
        
        encuesta.setIdAdmin(usuario);
     
        
        this.encuestaFacade.create(encuesta);
        
        }
        
        else{
            
            encuesta = this.encuestaFacade.find(id_int);
            
        }
        
        // Configurando un atributo de request
        request.setAttribute("encuesta", encuesta);
        
        request.setAttribute("pagina", "encuesta");
        
        // Llamada a la ventana crearPregunta
        RequestDispatcher rd = request.getRequestDispatcher("crearPregunta.jsp");
        //?=<%= encuesta.getId()%>"
        rd.forward(request, response);  
        
        
        
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
