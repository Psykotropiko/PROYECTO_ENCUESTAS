package encuestas.services;
import encuestas.dto.UsuariosDTO;
import encuestas.ejb.EncuestaFacade;
import encuestas.ejb.LogsFacade;
import encuestas.ejb.PreguntaFacade;
import encuestas.ejb.RespuestaFacade;
import encuestas.ejb.ResultadosFacade;
import encuestas.ejb.UsuariosFacade;
import encuestas.entity.Encuesta;
import encuestas.entity.Logs;
import encuestas.entity.Pregunta;
import encuestas.entity.Respuesta;
import encuestas.entity.Resultados;
import encuestas.entity.Usuarios;
import java.util.Date;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import encuestas.dto.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Manuel
 */
@Stateless
@Path("ws")
public class ServiciosREST {
    @EJB
    private ResultadosFacade resultadosFacade;
    
    @EJB
    private RespuestaFacade respuestaFacade;
    
    @EJB
    private PreguntaFacade preguntaFacade;
    
    @EJB
    private EncuestaFacade encuestaFacade;
    
    @EJB
    private LogsFacade logsFacade;
    
    @EJB
    private UsuariosFacade usuariosFacade;
    //SERVICIO DE LOGIN.
    @GET
    @Path("login/{correo}/{pass}")
    @Produces({MediaType.APPLICATION_JSON})
    public UsuariosDTO find(@PathParam("correo") String correo,@PathParam("pass") String password) {
        Usuarios user = this.usuariosFacade.comprobarUsuario(correo);  
        
        if (user == null || !user.getPassword().equals(password)) {
          return null;
        }else{    
          return user.crearDTO();
        }          
    }
    //SERVICIO DE REGISTRO
    @POST
//    @Override
    @Path("registro/newuser/{correo2}/{pass2}")
    public String Registro( @PathParam("correo2") String correoAR, @PathParam("pass2")String passwordAR) {
        String message = "Error, el usuario ya existe";
        Usuarios user = this.usuariosFacade.comprobarUsuario(correoAR);
            if (user == null || !user.getCorreo().equals(correoAR)) {
                Usuarios nuevo = new Usuarios();
                nuevo.setCorreo(correoAR);
                nuevo.setPassword(passwordAR);
                nuevo.setStatus("1");
                this.usuariosFacade.create(nuevo);
            } else {
            return message;
            }
        return null;
    }
    // AÑADIR LOG A DB
    @POST
    @Path("log/add/{id_usuario}/{id_encuesta}")
    public void añadirLog(@PathParam("id_usuario") String id_usuario, @PathParam("id_encuesta") String id_encuesta){
        Usuarios usuario = this.usuariosFacade.find(new Integer(id_usuario));
        Encuesta encuesta = this.encuestaFacade.find(new Integer(id_encuesta));
        // Se crea el log
        Logs log = new Logs();
        log.setIdUsuario(usuario);
        log.setIdEncuesta(encuesta);
        log.setFecha(new Date());
        this.logsFacade.create(log);
    }
    
    // DEVOLVER LOG MEDIANTE ID
    @GET
    @Path("get/log/{id_log}")
    @Produces({MediaType.APPLICATION_JSON})
    public LogsDTO findLog(@PathParam("id_log") String id_log){
        return this.logsFacade.find(new Integer(id_log)).crearDTO();
    }
    
    @GET
    @Path("get/listaLogs")
    @Produces({MediaType.APPLICATION_JSON})
    public List<LogsDTO> findAllLogs(){
        List<Logs> logs = this.logsFacade.findAll();
        List<LogsDTO> logs_dto = new ArrayList<>();
        for(Logs log : logs){
            logs_dto.add(log.crearDTO());
        }
        return logs_dto;
    }
    
    @POST
    @Path("resultado/add/{id_pregunta}/{id_respuesta}/{id_log}")
    public void añadirResultado(@PathParam("id_pregunta") String id_pregunta, @PathParam("id_respuesta") String id_respuesta, @PathParam("id_log") String id_log){
        Pregunta pregunta = this.preguntaFacade.find(new Integer(id_pregunta));
        Respuesta respuesta = this.respuestaFacade.find(new Integer(id_respuesta));
        Logs log = this.logsFacade.find(new Integer(id_log));
        Resultados resultado = new Resultados(log.getId(), pregunta.getId());
        resultado.setLogs(log);
        resultado.setPregunta(pregunta);
        resultado.setIdRespuesta(respuesta);
        this.resultadosFacade.create(resultado);
    }
    
    @GET
    @Path("get/resultado/{id_pregunta}")
    @Produces({MediaType.APPLICATION_JSON})
    public  List<RespuestaDTO> findResultado(@PathParam("id_pregunta") String id_pregunta){
        Pregunta pregunta = this.preguntaFacade.find(new Integer(id_pregunta));
        return pregunta.crearDTO().getRespuestaList();
    }
    
    @GET
    @Path("listado_pregunta/{id_encuesta}")
    @Produces({MediaType.APPLICATION_JSON})
    public List<PreguntaDTO> findAll(@PathParam("id_encuesta") String id ) { 
         Encuesta encuesta = this.encuestaFacade.find(new Integer(id));
         List<Pregunta> lista_pregunta = encuesta.getPreguntaList();
         List<PreguntaDTO> lista_dto = new ArrayList<>();
         for(Pregunta pregunta : lista_pregunta){
             lista_dto.add(pregunta.crearDTO());
         }
         return lista_dto;
    }
    @GET
    @Path("encuestas/")
    @Produces({MediaType.APPLICATION_JSON})
    public List<EncuestaDTO> buscarEncuestas() {
        List<Encuesta> lista = this.encuestaFacade.findAll();
        List<EncuestaDTO> encuestas = new ArrayList();
        if (lista != null){
            for (Encuesta enc: lista) {
                encuestas.add(enc.crearDTO());
            }
        }
            return encuestas;
        }
    
}
    

//    @PersistenceContext(unitName = "EncuestasPU")
//    private EntityManager em;
//
//    public ServiciosREST() {
//        super(Usuarios.class);
//    }
//
//    @POST
//    @Override
//    @Consumes({MediaType.APPLICATION_JSON})
//    public void create(Usuarios entity) {
//        super.create(entity);
//    }
//
//    @PUT
//    @Path("{id}")
//    @Consumes({MediaType.APPLICATION_JSON})
//    public void edit(@PathParam("id") Integer id, Usuarios entity) {
//        super.edit(entity);
//    }
//
//    @DELETE
//    @Path("{id}")
//    public void remove(@PathParam("id") Integer id) {
//        super.remove(super.find(id));
//    }
//
//    @GET
//    @Path("{id}")
//    @Produces({MediaType.APPLICATION_JSON})
//    public Usuarios find(@PathParam("id") Integer id) {
//        return super.find(id);
//    }
//
//    @GET
//    @Override
//    @Produces({MediaType.APPLICATION_JSON})
//    public List<Usuarios> findAll() {
//        return super.findAll();
//    }
//
//    @GET
//    @Path("{from}/{to}")
//    @Produces({MediaType.APPLICATION_JSON})
//    public List<Usuarios> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
//        return super.findRange(new int[]{from, to});
//    }
//
//    @GET
//    @Path("count")
//    @Produces(MediaType.TEXT_PLAIN)
//    public String countREST() {
//        return String.valueOf(super.count());
//    }
//
//    @Override
//    protected EntityManager getEntityManager() {
//        return em;
//    }